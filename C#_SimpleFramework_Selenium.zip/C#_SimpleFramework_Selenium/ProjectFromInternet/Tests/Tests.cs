﻿using NUnit.Framework;

namespace ProjectFromInternet
{
    [TestFixture]
    public class Tests : TestSettings
    {

        [Test]
        [Retry(2)]
        public void ContactUsTest([Values("Value1", "Value2")] string values)
        {
            HomePage homePage = new HomePage(Driver);

            homePage.GoToContactUsPage()
                    .ContactUsPage()
                    .WaitingForElementeader();
        }

        [Test]
        public void SignInTest()
        {
            HomePage homePage = new HomePage(Driver);

            homePage.GoToSignInPage()
                    .SignInPage()
                    .GoingToContactUsAgain()
                    .ContactUsPage();
        }
    }

}
