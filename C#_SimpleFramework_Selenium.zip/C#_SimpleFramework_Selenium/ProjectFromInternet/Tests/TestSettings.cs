﻿using NUnit.Framework;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;

namespace ProjectFromInternet
{
    public class TestSettings
    {
        public IWebDriver Driver;
        private readonly string url = @"http://automationpractice.com";

        [SetUp]
        public void SetupTest()
        {
            Driver = new ChromeDriver();
            Driver.Navigate().GoToUrl(url);          
        }

        [TearDown]
        public void EveryTimeTearDown()
        {
             Driver.Quit();
        }

    }
}
