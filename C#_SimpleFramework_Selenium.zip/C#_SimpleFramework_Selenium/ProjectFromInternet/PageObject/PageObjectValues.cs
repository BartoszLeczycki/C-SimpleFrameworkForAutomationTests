﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectFromInternet.PageObject
{
    public class PageObjectValues
    {
        protected IWebDriver Driver;
        protected WebDriverWait Wait;

    }
}
