﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using ProjectFromInternet.PageObject;

namespace ProjectFromInternet
{
    public class HomePage : PageObjectValues
    { 

        public HomePage(IWebDriver driver)
        {
            this.Driver = driver;
            Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(30));
            PageFactory.InitElements(driver, this);
        }


        [FindsBy(How = How.XPath, Using = "//div[@id='contact-link']")]
        protected IWebElement ContactUsButton;

        [FindsBy(How = How.XPath, Using = "//a[@class='login']")]
        protected IWebElement SignInButton;

        public ContactUs GoToContactUsPage()
        {
            ContactUsButton.Click();
            return new ContactUs(Driver);
        }


        public SignIn GoToSignInPage()
        {
            SignInButton.Click();
            return new SignIn(Driver);
        }



    }
}
