﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using ProjectFromInternet.PageObject;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectFromInternet
{
    public class SignIn : PageObjectValues
    {      
        public SignIn(IWebDriver driver) :base(driver)
        { }

        public SignIn SignInPage()
        {
            return this;
        }

        public ContactUs GoingToContactUsAgain()
        {
            return new ContactUs(Driver);
        }

    }
}
