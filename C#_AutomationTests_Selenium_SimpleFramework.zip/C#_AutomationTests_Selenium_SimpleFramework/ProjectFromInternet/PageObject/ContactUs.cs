﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using ProjectFromInternet.PageObject;
using System;

namespace ProjectFromInternet
{
    public class ContactUs : PageObjectValues
    {
        public ContactUs(IWebDriver driver) :base(driver)
        {
        }

        [FindsBy(How = How.XPath, Using = "//h3[@class='page-subheading']")]
        protected IWebElement SendMessageHeaderOnContactUsPage;
        public ContactUs ContactUsPage()
        {
            return this;
        }

        public ContactUs WaitingForElementeader()
        {
            WaitForElement(SendMessageHeaderOnContactUsPage);
            return this;
        }

        public void WaitForElement(IWebElement element)
        {
            Wait.Until(ExpectedConditions.ElementToBeClickable(element));
        }

    }
}
