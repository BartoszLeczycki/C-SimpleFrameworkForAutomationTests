﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;

namespace ProjectFromInternet
{
    public class HomePage
    {
        private readonly IWebDriver driver;
        private readonly string url = @"https://github.com/corker/NOpenPage";
        private readonly WebDriverWait Wait;

        public HomePage(IWebDriver browser)
        {
            this.driver = browser;
            Wait = new WebDriverWait(browser, TimeSpan.FromSeconds(30));
            PageFactory.InitElements(browser, this);
        }


        [FindsBy(How = How.XPath, Using = "//div[@id='contact-link']")]
        protected IWebElement ContactUsButton;

        [FindsBy(How = How.XPath, Using = "//a[@class='login']")]
        protected IWebElement SignInButton;

        public ContactUs GoToContactUsPage()
        {
            ContactUsButton.Click();
            return new ContactUs(driver);
        }


        public SignIn GoToSignInPage()
        {
            SignInButton.Click();
            return new SignIn(driver);
        }



    }
}
