﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;

namespace ProjectFromInternet
{
    public class ContactUs
    {
        private readonly IWebDriver driver;
        private readonly WebDriverWait Wait;

        public ContactUs(IWebDriver browser)
        {
            this.driver = browser;
            Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            PageFactory.InitElements(browser, this);
        }

        [FindsBy(How = How.XPath, Using = "//h3[@class='page-subheading']")]
        protected IWebElement SendMessageHeaderOnContactUsPage;
        public ContactUs ContactUsPage()
        {
            return this;
        }

        public ContactUs WaitingForElementeader()
        {
            WaitForElement(SendMessageHeaderOnContactUsPage);
            return this;
        }

        public void WaitForElement(IWebElement element)
        {
            Wait.Until(ExpectedConditions.ElementToBeClickable(element));
        }

    }
}
