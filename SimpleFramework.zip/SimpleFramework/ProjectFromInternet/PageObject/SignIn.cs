﻿using OpenQA.Selenium;
using OpenQA.Selenium.Support.PageObjects;
using OpenQA.Selenium.Support.UI;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectFromInternet
{
    public class SignIn
    {
        protected IWebDriver Driver;
        protected WebDriverWait Wait;
        
        public SignIn(IWebDriver driver)
        {
            this.Driver = driver;
            Wait = new WebDriverWait(driver, TimeSpan.FromSeconds(60));
            PageFactory.InitElements(driver, this);
        } 

        public SignIn SignInPage()
        {
            return this;
        }

        public ContactUs GoingToContactUsAgain()
        {
            return new ContactUs(Driver);
        }

    }
}
